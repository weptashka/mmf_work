docker network ls
docker network inspect app-tier 
