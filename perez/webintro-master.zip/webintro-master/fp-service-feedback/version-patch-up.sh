versiony version.json --patch
