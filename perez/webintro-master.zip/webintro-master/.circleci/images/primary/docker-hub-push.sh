docker login
docker push pangramia/circleci-docker-primary:0.0.1
