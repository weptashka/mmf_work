docker build -t pangramia/circleci-docker-primary:0.0.1 .
