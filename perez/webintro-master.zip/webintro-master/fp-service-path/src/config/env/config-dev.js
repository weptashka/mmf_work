const env = {
  options: {
    logger: {
      prettyPrint: true,
      level: 'info'
    }
  }
}

module.exports = env
