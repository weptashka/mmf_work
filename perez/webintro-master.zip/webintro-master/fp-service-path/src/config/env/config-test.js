const env = {
  port: 0,
  options: {
    logger: {
      prettyPrint: true,
      level: 'info'
    }
  }
}

module.exports = env
