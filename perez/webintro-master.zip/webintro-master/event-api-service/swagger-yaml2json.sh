java -jar ./utils/swagger-codegen-cli-3.0.16.jar  generate -i api/swagger/swagger.yaml -l openapi -o ./gen

