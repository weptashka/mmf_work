swagger-codegen generate -i api/swagger/swagger.yaml -l html -o public/
