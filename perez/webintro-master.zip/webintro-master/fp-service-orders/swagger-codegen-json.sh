swagger-codegen generate -i api/swagger/swagger.yaml -l openapi -o api/swagger/
