npm install @openapitools/openapi-generator-cli -g
openapi-generator generate -g typescript-fetch -i api/swagger/openapi.json -o ./codegen/ts